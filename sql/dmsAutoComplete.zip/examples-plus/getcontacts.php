<?
ini_set("display_errors",1);

function destacaTexto($highlite,$string){
	return str_ireplace($highlite,"<b>".$highlite."</b>",$string);
}

//Criar documento XML atraves de DOM
//Create XML Doc through DOM
$xmlDoc = new DOMDocument('1.0', 'utf-8');
$xmlDoc->formatOutput = true;

//Criar elementos Ra�z do XML
//Create root XML element
$root = $xmlDoc->createElement('root');
$root = $xmlDoc->appendChild($root);

//Abrir conex�o com BD
try {
	$dbh = new PDO('mysql:host=localhost;dbname=dmsac', 'root', 'rafa50');

	//Preparar Query
	
	$results = $dbh->query("SELECT idcontatos, nome, email, cargo FROM contatos
                     		WHERE
                         		nome LIKE '%".$_POST['string']."%'
                         	OR
                         		email LIKE '%".$_POST['string']."%'
                         	OR
                         		cargo LIKE '%".$_POST['string']."%'");
	while ($row = $results->fetch(PDO::FETCH_ASSOC)){
		//Cadastrar na lista
		//Add to list
		$item = $xmlDoc->createElement('item');
		$item = $root->appendChild($item);
		$item->setAttribute('id',$row['idcontatos']);
		$texto = $row['nome']."(".$row['cargo'].") "."<".$row['email'].">";
		$label = destacaTexto($_POST['string'],$texto);
		$item->setAttribute('label',rawurlencode($label));
		$item->setAttribute('flabel',rawurlencode($texto));
		
		//Problema: o texto que volta para o cmapo vai com tags doidas.. e deveria ir apenas o texto, precisamos de um label e um 
		// campo "show" opcional
		
		//rawurlencode evita problemas de charset
		//rawurlencode avoids charset problems
	}


	$dbh = null;
} catch (PDOException $e) {
	$item = $xmlDoc->createElement('item');
	$item = $root->appendChild($item);
	$item->setAttribute('id','0');
	$label = $e->getMessage();
	$item->setAttribute('label',rawurlencode($label));
}

//Retornar XML de resultado para AJAX
//Return XML code for AJAX Request
header("Content-type:application/xml; charset=utf-8");
echo $xmlDoc->saveXML();

?>