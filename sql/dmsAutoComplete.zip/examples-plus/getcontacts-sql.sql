-- 
-- Table structure for table `contatos`
-- 

CREATE TABLE `contatos` (
  `idcontatos` int(10) unsigned NOT NULL auto_increment,
  `nome` varchar(60) default NULL,
  `email` varchar(60) default NULL,
  `cargo` varchar(60) default NULL,
  PRIMARY KEY  (`idcontatos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `contatos`
-- 

INSERT INTO `contatos` VALUES (1, 'Rafael Dohms', 'rafael@rafaeldohms.com.br', 'Presidente');
INSERT INTO `contatos` VALUES (2, 'Viktor Dohms', 'fulano@terra.com.br', 'Consultor');
